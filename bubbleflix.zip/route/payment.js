const express = require("express");
const SquareConnect = require("square-connect");
const uuidv4 = require("uuid/v4");
const router = express.Router();

// keys
const keys = require("../config/keys");

// configurations
const defaultClient = SquareConnect.ApiClient.instance;
const oauth2 = defaultClient.authentications["oauth2"];
oauth2.accessToken = keys.access_token;

const stripe = require('stripe')(keys.stripe_secret_key);

router.get("/", (req, res) => {
  res.render("index");
});

router.get("/success", (req, res) => {
  res.render("success");
});

router.post("/checkout", async (req, res) => {
  const apiInstance = new SquareConnect.CheckoutApi();

  try {
    const body = {
      order: req.body.order,
      redirect_url: req.body.redirect_url,
      idempotency_key: uuidv4(),
      ask_for_shipping_address: true,
      merchant_support_email: "merchant+support@website.com"
    };

    const data = await apiInstance.createCheckout(keys.location_id, body);
    res.status(200).send(data);
  } catch (e) {
    res.status(400).send(e);
  }
});

router.get("/validate/:id", async (req, res) => {
  const apiInstance = new SquareConnect.TransactionsApi();
  const transactionId = req.params.id;

  try {
    const data = await apiInstance.retrieveTransaction(
      keys.location_id,
      transactionId
    );

    res.status(200).send(data);
  } catch (e) {
    if (e.status === 404) {
      res.status(400).send({ message: "No transaction found with this id" });
      return;
    }
    res.status(400).send(e);
  }
});

//Stripe payment
router.post('/stripe', async (req, res) => { 
  
  stripe.charges.create({
      amount: req.body.amount,
      currency: req.body.currency,
      source: req.body.token,
  }).then((charge) => {
      // asynchronously called
        res.status(200).send(charge);
  })
  .catch(err =>{
      console.log(err);
      res.status(400).send(err)
  });
  
  // Moreover you can take more details from user 
  // like Address, Name, etc from form 
  // stripe.customers.create({ 
  //     email: req.body.userEmail, 
  //     source: req.body.stripeToken, 
  //     name: req.body.userName, 
  //     address: { 
  //         line1: 'TC 9/4 Old MES colony', 
  //         postal_code: '452331', 
  //         city: 'Indore', 
  //         state: 'Madhya Pradesh', 
  //         country: 'India', 
  //     } 
  // }) 
  // .then((customer) => { 

  //     return stripe.charges.create({ 
  //         amount: req.body.amount * 100,     // Charing Rs 25 
  //         description: 'Run Ad Payment on Bubble App', 
  //         currency: 'USD', 
  //         customer: customer.id 
  //     }); 
  // }) 
  // .then((charge) => { 
  //     res.status(200).send("Success");      
  // }) 
  // .catch((err) => { 
  //     res.status(400).send(err)       // If some error occurs 
  // }); 
}) 

module.exports = router;
