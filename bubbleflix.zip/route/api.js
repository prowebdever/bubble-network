const express = require("express");
const keys = require("../config/keys");
const router = express.Router();

const { makeEmailTemplate } = require("../config/helpers");
const { sendMessage } = require("../config/gmail");

router.post("/sendemail", async (req, res) => {
  const to = "owner@bubbleflix.com";
  const { subject, authenticationKey, data: dataFromClient } = req.body;

  try {
    const data = { to, subject };

    // just to ensure that api is called with the proper authentication key
    if (authenticationKey !== keys.unique_secret_for_gmail_api)
      throw { message: "You are not authorized to use this api" };

    const message = makeEmailTemplate(dataFromClient);
    data.message = message;

    await sendMessage(data);
    res.status(200).send({ message: "Email sent!" });
  } catch (e) {
    console.log("e =>", e);
    const message =
      e.message === "You are not authorized to use this api"
        ? e.message
        : "There was a problem sending this email, try again later";

    res.status(400).send({ message });
  }
});

module.exports = router;
