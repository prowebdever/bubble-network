const express = require("express");
const FCM = require('fcm-node');
const router = express.Router();

// firebase
const firebase = require("firebase");

const keys = require("../config/keys");
const fcm = new FCM(keys.push_auth_key);

firebase.initializeApp(keys.firebaseConfig);
const db = firebase.firestore();

const collection = 'live_streaming';

const get_registration_ids = async (uid, friends) => {  
  let user = await get_user(uid);
  let registration_ids = [];
  for(var i=0;i<friends.length;i++) {
    let _user = await get_user(friends[i]);
    if(_user && _user.token) {
      registration_ids.push(_user.token);
    }
  }
  return {user: user, registration_ids: registration_ids};
}

const get_user = async (uid) => {
  try{
    let document  = db.collection('users').doc(uid);
    let item = await document.get();    
    return item.data();    
  } catch(error) {
    
  }
  return null;
}

const push_notification = (uid, is_start, user, registration_ids, callback) => {
  if(user && registration_ids.length>0) {
    let body = user.username;
    if(is_start) {
      body += ' started live video streaming';
    } else {
      body += ' stopped live video streaming';
    }
    let message = {
      notification:{
        title: "Kittykat Bubble Notification",
        body: body,
        sound: "default",
        click_action: "FCM_PLUGIN_ACTIVITY",
        icon: "ic_launcher",
        badge: "1"
      },
      data:{
        event: 'live_stream',
        uid: uid,
        username: user.username,
        is_start: is_start
      },
      registration_ids: registration_ids,
      priority: "high",
      restricted_package_name: ""
    };    
    fcm.send(message, (err, response) => {
      if (err) {
          console.log("Something has gone wrong!", JSON.stringify(err));
          callback(err);
      } else {
          console.log("Successfully sent with response: ", response);
          callback(response);
      }
    })        
  } else {
    callback('No user or token exist');
  }
}

const push_chat_message = (username, chat_id, registration_ids, msg, callback) => {
  if(registration_ids.length>0) {    
    let message = {
      notification:{
        title: username + '\'s message',
        body: msg,
        sound: "default",
        click_action: "FCM_PLUGIN_ACTIVITY",
        icon: "ic_launcher",
        badge: "1"
      },
      data:{
        event: 'chat',
        chat_id: chat_id,
        username: username,
        message: msg
      },
      registration_ids: registration_ids,
      priority: "high",
      restricted_package_name: ""
    };    
    fcm.send(message, (err, response) => {
      if (err) {
          console.log("Something has gone wrong!", JSON.stringify(err));
          callback(err);
      } else {
          console.log("Successfully sent with response: ", response);
          callback(response);
      }
    })        
  } else {
    callback('No user or token exist');
  }
}

router.post('/start_stream', async (req, res) => { 
  let uid = req.body.uid, is_start = req.body.is_start;
  try {
    let document  = db.collection(collection).doc(uid);
    let item = await document.get();
    let friends = item.data().friends;
    let result = await get_registration_ids(uid, friends);
    if(result) {
      push_notification(uid, is_start, result.user, result.registration_ids, (response) => {
        res.status(200).send(response);    
      });
    } else {
      res.status(200).send(null);
    }
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }  
});

router.post('/send_message', async (req, res) => { 
  let uid = req.body.uid, chat_id = req.body.chat_id, users = req.body.users, message = req.body.message;
  users = users.split(',');
  try {
    let document  = db.collection(collection).doc(uid);
    let item = await document.get();    
    let result = await get_registration_ids(uid, users);
    if(result) {
      push_chat_message(item.username, chat_id, result.registration_ids, message, (response) => {
        res.status(200).send(response);    
      });
    } else {
      res.status(200).send(null);
    }
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }  
});

router.post('/get_timestamp', async(req, res) => {
  var d = new Date(1970, 0, 1, 0, 0, 0, 0);
  var result = {
    timestamp: Date.now(),
    offset: d.getTime()
  };
  res.status(200).send(result);
});

module.exports = router;
