import React, { Component } from "react";
import { BrowserRouter, Route } from "react-router-dom";
import { Container } from "reactstrap";

import Login from "../screens/Login/Login";
import Home from "../screens/Home/Home";
import Ads from "../screens/Ads/Ads";
import Header from "../components/Header";

export default class Router extends Component {
  render() {
    return (
      <BrowserRouter>
        <Header />
        <Container fluid>
          <Route path="/" exact component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/ads/:id" component={Ads} />
        </Container>
      </BrowserRouter>
    );
  }
}
