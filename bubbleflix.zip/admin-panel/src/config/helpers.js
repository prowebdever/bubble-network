const saveLocalStorage = (data, key) => {
  localStorage.setItem(key, JSON.stringify(data));
};

const readLocalStorage = key => {
  return JSON.parse(localStorage.getItem(key));
};

const removeLocalStorage = key => {
  localStorage.removeItem(key);
};

const helpers = {
  saveLocalStorage,
  readLocalStorage,
  removeLocalStorage
};

export default helpers;
