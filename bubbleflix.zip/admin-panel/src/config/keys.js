const keys = {
  firebaseConfig: {
    apiKey: "AIzaSyBILV0TU7teqen2fDH2qZoGpCGAB-FUFOM",
    authDomain: "kittykat-f2c10.firebaseapp.com",
    databaseURL: "https://kittykat-f2c10.firebaseio.com",
    projectId: "kittykat-f2c10",
    storageBucket: "kittykat-f2c10.appspot.com",
    messagingSenderId: "793790968316"
  },
  adminEmail: "ytd9755@gmail.com"
};

export default keys;
