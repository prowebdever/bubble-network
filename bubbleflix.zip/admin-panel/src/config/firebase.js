import firebaseLib from "firebase/app";
import "firebase/firestore";
import "firebase/auth";

import keys from "./keys";

firebaseLib.initializeApp(keys.firebaseConfig);

const login = async credentials => {
  try {
    const user = await firebaseLib
      .auth()
      .signInWithEmailAndPassword(credentials.email, credentials.password);

    const uid = user.user.uid;

    const response = await readDocument("users", uid, true);

    return { uid, ...response };
  } catch (e) {
    throw e;
  }
};

const readDocument = async (collection, document, onlyData) => {
  try {
    const response = await firebaseLib
      .firestore()
      .collection(collection)
      .doc(document)
      .get();

    if (onlyData) return response.data();

    return response;
  } catch (e) {
    throw e;
  }
};

const deleteDocument = (collection, document) => {
  return firebaseLib
    .firestore()
    .collection(collection)
    .doc(document)
    .delete();
};

const updateDocument = (collection, document, data) => {
  return firebaseLib
    .firestore()
    .collection(collection)
    .doc(document)
    .set(data, { merge: true });
};

const logout = () => {
  return firebaseLib.auth().signOut();
}

const firebase = {
  login,
  readDocument,
  deleteDocument,
  updateDocument,
  logout
};

export default firebase;
