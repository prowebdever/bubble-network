import React, { Component } from "react";

export default class Loader extends Component {
  render() {
    const { text = "Please wait..." } = this.props;
    return (
      <div style={Styles.mainContainer}>
        <div style={Styles.loaderContainer}>
          <img
            src={require("../assets/icon/spinner.gif")}
            alt="loader"
            style={Styles.loader}
          />
          <p>{text}</p>
        </div>
      </div>
    );
  }
}

const Styles = {
  mainContainer: {
    position: "fixed",
    top: 0,
    left: 0,
    zIndex: 1000,
    height: "100vh",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },
  loaderContainer: {
    backgroundColor: "white",
    textAlign: "center",
    padding: "15px 80px",
    border: "1px solid black"
  },
  loader: {
    width: "80px"
  }
};
