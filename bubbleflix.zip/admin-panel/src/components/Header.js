import React from "react";
import {
  Navbar,
  NavbarBrand,
  Nav,
  NavItem,
  Button
} from "reactstrap";
import { withRouter } from "react-router";

import helpers from "../config/helpers";
import firebase from "../config/firebase";

class Header extends React.Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }

  componentDidMount() {
    const user = helpers.readLocalStorage("user");

    this.setState({ user });
  }

  logout = async () => {
    try {
      const { history } = this.props;

      await firebase.logout();

      helpers.removeLocalStorage("user");

      this.setState({ user: null }, () => history.replace("/login"));
    } catch (e) {
      console.log("e =>", e);
    }
  };

  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }

  render() {
    const { user } = this.state;

    return (
      <Navbar color="dark" dark expand="md">
        <NavbarBrand href="/">Bubble Flix</NavbarBrand>
        {user && (
          <Nav className="ml-auto" navbar>
            <NavItem>
              <Button color="danger" onClick={this.logout}>
                Log out
              </Button>
            </NavItem>
          </Nav>
        )}
      </Navbar>
    );
  }
}

export default withRouter(Header);
