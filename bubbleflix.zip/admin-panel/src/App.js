import React, { Component } from "react";

import Router from "./config/Router";
import helpers from "./config/helpers";
class App extends Component {
  componentDidMount() {
    const user = helpers.readLocalStorage("user");

    if (!user && window.location.pathname !== "/login") {
      window.location.assign("/login");
    } else if (user && window.location.pathname === "/login") {
      window.location.assign("/");
    }
  }

  render() {
    return <Router />;
  }
}

export default App;
