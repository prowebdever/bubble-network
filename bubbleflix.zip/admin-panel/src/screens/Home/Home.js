import React, { Component } from "react";
import firebaseLib from "firebase/app";
import "firebase/firestore";
import {
  Table,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter
} from "reactstrap";

import Loader from "../../components/Loader";
import firebase from "../../config/firebase";
import swal from "sweetalert";

export default class Home extends Component {
  constructor() {
    super();

    this.state = {
      users: [],
      modal: false,
      isLoading: true,
      loaderText: "Getting Users..."
    };
  }

  componentDidMount() {
    this.readUsersRealTime();
  }

  readUsersRealTime() {
    firebaseLib
      .firestore()
      .collection("users")
      .onSnapshot(querySnapshot => {
        const users = [];

        querySnapshot.forEach(res => {
          const data = res.data();

          if (data.status !== "deleted") users.push({ uid: res.id, ...data });
        });

        this.setState({
          users,
          isLoading: false,
          loaderText: "Please wait..."
        });
      });
  }

  updateStatus = async (uid, status, isConfirmed) => {
    try {
      this.setState({ modal: false });
      const { selectedUid } = this.state;

      if (status === "deleted" && !isConfirmed) {
        this.setState({ selectedUid: uid });
        this.toggle();
        return;
      }

      if (isConfirmed) uid = selectedUid;

      this.setState({ isLoading: true });
      await firebase.updateDocument("users", uid, { status });

      swal("Oops", "Status updated", "success");
    } catch (e) {
      swal("Oops", e.message, "error");
    }

    this.setState({ isLoading: false });
  };

  navigateToAds(uid) {
    const { history } = this.props;

    history.push(`/ads/${uid}`);
  }

  toggle = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  };

  renderUsers(user, index) {
    return (
      <tr key={Math.random().toString()}>
        <th scope="row">{index + 1}</th>
        <td>{user.username}</td>
        <td>{user.email}</td>
        <td>{user.country}</td>
        <td>{user.gender}</td>
        <td>{user.status === "verified" ? "Verified" : "Not verified"}</td>
        <td>
          {user.status === "blocked" ? (
            <Button
              onClick={this.updateStatus.bind(this, user.uid, "normal", false)}
              color="danger"
              size="sm"
              block
            >
              Unblock
            </Button>
          ) : (
            <Button
              onClick={this.updateStatus.bind(this, user.uid, "blocked", false)}
              color="danger"
              size="sm"
              block
            >
              Block
            </Button>
          )}
        </td>
        <td>
          <Button
            onClick={this.updateStatus.bind(this, user.uid, "verified", false)}
            color="primary"
            size="sm"
            block
          >
            Verify
          </Button>
        </td>
        <td>
          <Button
            onClick={this.updateStatus.bind(this, user.uid, "deleted", false)}
            color="danger"
            size="sm"
            block
          >
            Delete
          </Button>
        </td>
        <td>
          <Button
            color="primary"
            size="sm"
            block
            onClick={this.navigateToAds.bind(this, user.uid)}
          >
            View Ads
          </Button>
        </td>
      </tr>
    );
  }

  render() {
    const { users, isLoading, loaderText } = this.state;

    return (
      <div>
        <div className="mt-3">
          <h3>All Users</h3>
          {!!users.length && (
            <Table borderless hover responsive>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Country</th>
                  <th>Gender</th>
                  <th>Verified</th>
                  <th colSpan="4" className="text-center">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {users.map((u, index) => this.renderUsers(u, index))}
              </tbody>
            </Table>
          )}
        </div>
        <Modal
          isOpen={this.state.modal}
          toggle={this.toggle}
          className={this.props.className}
        >
          <ModalHeader toggle={this.toggle}>Confirm</ModalHeader>
          <ModalBody>
            This will permanently delete this user and you can't be able to
            retrieve it back. Do you want to continue?
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.toggle}>
              No
            </Button>
            <Button
              color="danger"
              onClick={this.updateStatus.bind(this, "", "deleted", true)}
            >
              Confirm
            </Button>
          </ModalFooter>
        </Modal>
        {isLoading && <Loader text={loaderText} />}
      </div>
    );
  }
}
