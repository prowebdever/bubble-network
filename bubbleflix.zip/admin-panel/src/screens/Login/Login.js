import React, { Component } from "react";
import {
  Form,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  Row,
  Col,
  Button
} from "reactstrap";

import firebase from "../../config/firebase";
import keys from "../../config/keys";
import helpers from "../../config/helpers";
import Loader from "../../components/Loader";
export default class Login extends Component {
  constructor() {
    super();

    this.state = {
      email: "",
      error: "",
      password: "",
      isLoading: false
    };
  }

  login = async e => {
    try {
      e.preventDefault();

      const { email, password } = this.state;
      const { history } = this.props;

      if (email !== keys.adminEmail)
        throw { message: "Sorry! only admins are allowed here" };

      this.setState({ isLoading: true });
      const response = await firebase.login({ email, password });

      this.clearFields(true);
      helpers.saveLocalStorage(response, "user");
      window.location.assign("/")
    } catch (e) {
      this.setState({ error: e.message });
      this.clearFields(false);
    }
    
    this.setState({ isLoading: false });
  };

  clearFields = shouldEmail => {
    let { email } = this.state;

    if (shouldEmail) email = "";

    this.setState({ password: "", email });
  };

  render() {
    const { email, password, error, isLoading } = this.state;

    return (
      <Row className="justify-content-center mt-5">
        <Col sm={10} md={6}>
          <Form onSubmit={this.login}>
            <FormGroup>
              <Label for="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                onChange={e =>
                  this.setState({ email: e.target.value, error: "" })
                }
                value={email}
                invalid={!!error}
              />
            </FormGroup>
            <FormGroup>
              <Label for="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                onChange={e =>
                  this.setState({ password: e.target.value, error: "" })
                }
                value={password}
                invalid={!!error}
              />
              <FormFeedback>{error}</FormFeedback>
            </FormGroup>
            <FormGroup>
              <Row>
                <Col xs={12} sm={4}>
                  <Button block>Login</Button>
                </Col>
              </Row>
            </FormGroup>
          </Form>
        </Col>
        {isLoading && <Loader text="Please wait..." />}
      </Row>
    );
  }
}
