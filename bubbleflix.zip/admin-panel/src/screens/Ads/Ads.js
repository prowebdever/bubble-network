import React, { Component } from "react";
import firebaseLib from "firebase/app";
import "firebase/firestore";
import {
  Row,
  Col,
  Card,
  CardBody,
  Button,
  CardTitle,
  CardText,
  CardImg,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter
} from "reactstrap";

import Loader from "../../components/Loader";
import firebase from "../../config/firebase";

import swal from "sweetalert";
export default class Ads extends Component {
  constructor() {
    super();

    this.state = {
      ads: [],
      isLoading: true,
      loaderText: "Getting ads...",
      modal: false
    };
  }

  componentDidMount = () => {
    const { id } = this.props.match.params;

    this.fetchAdsRealTime(id);
  };

  fetchAdsRealTime = uid => {
    firebaseLib
      .firestore()
      .collection("ads")
      .where("userId", "==", uid)
      .onSnapshot(querySnapshot => {
        const ads = [];

        querySnapshot.forEach(snapshot =>
          ads.push({ id: snapshot.id, ...snapshot.data() })
        );

        this.setState({ ads, isLoading: false, loaderText: "Please wait..." });
      });
  };

  deleteAd = id => {
    this.setState({ selectedId: id });
    this.toggle();
  };

  confirmDelete = async () => {
    this.toggle();
    const { selectedId } = this.state;
    try {
      this.setState({ isLoading: true });

      await firebase.deleteDocument("ads", selectedId);

      swal("Oops", "Deleted", "success");
    } catch (e) {
      swal("Oops", e.message, "error");
    }
    this.setState({ isLoading: false });
  };

  blockAd = async id => {
    try {
      this.setState({ isLoading: true });
      await firebase.updateDocument("ads", id, { blocked: true });

      swal("Oops", "Blocked", "success");
    } catch (e) {
      swal("Oops", e.message, "error");
    }
    this.setState({ isLoading: false });
  };

  unblockAd = async id => {
    try {
      this.setState({ isLoading: true });
      await firebase.updateDocument("ads", id, { blocked: false });

      swal("Oops", "Unblocked", "success");
    } catch (e) {
      swal("Oops", e.message, "error");
    }
    this.setState({ isLoading: false });
  };

  renderAds(ad) {
    return (
      <Col className="mt-2" sm={6} md={3} key={Math.random().toString()}>
        <Card>
          <CardImg top width="100%" src={ad.imageURL} alt={ad.description} />
          <CardBody>
            <CardTitle>
              <b>Package:</b>
              <span className="d-block">
                {ad.package ? ad.package.slice(3) : "Free"}
              </span>
            </CardTitle>
            <CardText>
              <b>Description</b>
              <span className="d-block">{ad.description}</span>
            </CardText>
            <Row>
              {!ad.blocked ? (
                <Col lg={6}>
                  <Button
                    onClick={this.blockAd.bind(this, ad.id)}
                    className="mt-2"
                    color="primary"
                    size="sm"
                    block
                  >
                    Block
                  </Button>
                </Col>
              ) : (
                <Col lg={6}>
                  <Button
                    onClick={this.unblockAd.bind(this, ad.id)}
                    className="mt-2"
                    color="primary"
                    size="sm"
                    block
                  >
                    Unblock
                  </Button>
                </Col>
              )}
              <Col lg={6}>
                <Button
                  onClick={this.deleteAd.bind(this, ad.id)}
                  className="mt-2"
                  color="danger"
                  size="sm"
                  block
                >
                  Delete
                </Button>
              </Col>
            </Row>
          </CardBody>
        </Card>
      </Col>
    );
  }

  toggle = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  };

  render() {
    const { ads, isLoading, loaderText } = this.state;

    return (
      <div>
        {!!ads.length && (
          <Row className="mt-1 align-items-center">
            {ads.map(ad => this.renderAds(ad))}
          </Row>
        )}
        <Modal
          isOpen={this.state.modal}
          toggle={this.toggle}
          className={this.props.className}
        >
          <ModalHeader toggle={this.toggle}>Confirm</ModalHeader>
          <ModalBody>
            This will permanently delete this ad and you can't be able to
            retrieve it back. Do you want to continue?
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.toggle}>
              No
            </Button>
            <Button color="danger" onClick={this.confirmDelete}>
              Confirm
            </Button>
          </ModalFooter>
        </Modal>
        {isLoading && <Loader text={loaderText} />}
      </div>
    );
  }
}
