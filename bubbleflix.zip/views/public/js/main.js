// KEYS:
const ACCESS_TOKEN =
  "EAAAEGnGmMl2fctxtApMyPmZgCLlJhjGy-8U8VzIHotP5GmKuuY5gAAw-JLdRkas";
const LOCATION_ID = "CBASEKWAvd9gEzHIBSHjMOGO55EgAQ";

const BASE_URL = "https://connect.squareup.com/v2";

// EVENTS:
window.addEventListener("load", preparePage);

// FUNCTIONS:
function preparePage() {
  const urlParams = new URLSearchParams(window.location.search);
  const animationType = urlParams.get("animationType");
  const price = urlParams.get("price");

  if (!animationType || !price) return showError("Bad Request!");
  fetchCheckoutURL({ animationType, price });
}

async function fetchCheckoutURL(data) {
  try {
    const api = "payment/checkout";
    const headers = {
      "Content-Type": "application/json"
    };
    const body = {
      order: {
        line_items: [
          {
            name: data.animationType,
            quantity: "1",
            base_price_money: {
              amount: data.price * 100,
              currency: "USD"
            }
          }
        ]
      },
      redirect_url: `${window.location.origin}/payment/success`
    };

    const response = await fetch(api, {
      method: "POST",
      body: JSON.stringify(body),
      headers
    });

    const message = await response.json();

    window.location.assign(message.checkout.checkout_page_url);
  } catch (e) {
    showError(e.message);
  }
}

function showError(error) {
  const loaderContainerEl = document.querySelector("#loader-container");
  loaderContainerEl.innerHTML = `
    <h1>${error}</h1>
  `;
}

/*
    redBorderAnimation?: 10$
    starsAnimation?:     1$
    raysAnimation?:      20$
    coloredLinesAnimation?: 50$
*/
