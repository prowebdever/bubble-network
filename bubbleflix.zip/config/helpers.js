function makeEmailTemplate(data) {
  return `
            <div style="max-width: 700px;margin: 0 auto;width: 100%; font-family: Arial, Helvetica, sans-serif">
                <table style="width: 100%;border-collapse:collapse">
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black" colspan="2">Sender Account details</th>
                    </tr>
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">Username:</th>
                        <td style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">${data.username}</td>
                    </tr>
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">Email:</th>
                        <td style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">${data.email}</td>
                    </tr>
                </table>
            
                <table style="margin-top: 10px;width: 100%;border-collapse:collapse">
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black" colspan="2">Sent Details</th>
                    </tr>
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">Username:</th>
                        <td style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">${
                          data.badgeRequest.username
                        }</td>
                    </tr>
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">Full Name:</th>
                        <td style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">${
                          data.badgeRequest.fullName
                        }</td>
                    </tr>
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">nickname:</th>
                        <td style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">${
                          data.badgeRequest.nickName
                        }</td>
                    </tr>
                    <tr>
                        <th style="padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">Image:</th>
                        <td style="text-align: center;padding: 10px;box-sizing:border-box;width: 50%;border: 1px solid black">
                            <img src=${data.badgeRequest.image} width="80%;" />
                            <br />
                            <a href=${data.badgeRequest.image}>View in full size</a>
                        </td>
                    </tr>
                </table>
            </div>
        `;
}

exports.makeEmailTemplate = makeEmailTemplate;
