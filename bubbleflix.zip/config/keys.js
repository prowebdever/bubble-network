module.exports = {
    access_token: "EAAAEPXq7aq2ljthjtVmoY19NZs9S-s30DLn3gkN8GyT1JiLuzOL00c2VkOW08Z1",
    location_id: "81TW63075MCER",
    unique_secret_for_gmail_api: "8b96608b-2a68-4f2d-8d1c-34631e92a4c8",
    stripe_secret_key: 'sk_test_51HbCTAHdInK4l3MN1mDshyKCEzf2NFKOzNxsxpuXP9aqyT6N3AUKqGDWj0lbU8Jw4PhtQmk6kAfHaDxYhYudaNK400GOJV3SKs',
    stripe_publishable_key: 'pk_test_51HbCTAHdInK4l3MNS90PDpel0GWwrHVig9ROr7gx2l43zDmwBpGm6tQF8gyYgESkaCZmNjm0fc0ZyQ7lUo2mIsLk00N6iyehkX',
    push_auth_key: 'AAAAuNGg8fw:APA91bEDAGiTwT7dtgY0UGR19qYOFKctwojJDEf1XroFs2F-k0M8hvgCZct5aYj_jhprmTHzFt2ByTXZZew9QtU9Wd6wBMwFTU9hN-16It95Fyk1H1lnBmLdTMmomuil9oMtLOQI4NTy',
    firebaseConfig: {
        apiKey: "AIzaSyBILV0TU7teqen2fDH2qZoGpCGAB-FUFOM",
        authDomain: "kittykat-f2c10.firebaseapp.com",
        databaseURL: "https://kittykat-f2c10.firebaseio.com",
        projectId: "kittykat-f2c10",
        storageBucket: "kittykat-f2c10.appspot.com",
        messagingSenderId: "793790968316"
    }
}