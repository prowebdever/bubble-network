const express = require("express");
const exphbs = require("express-handlebars");
const cors = require("cors");
const { init } = require("./config/gmail");

const app = express();

const PORT = process.env.PORT || 4000;
// Middle wares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("views/public"));

// Templating Engine
app.engine("handlebars", exphbs({}));
app.set("view engine", "handlebars");

// route middlewares
app.use("/payment", require("./route/payment"));
app.use("/api", require("./route/api"));
app.use("/live_stream", require("./route/live_stream"));

if (process.env.NODE_ENV === "production") {
  app.use(express.static("admin-panel/build"));

  const path = require("path");
  app.get("*", (req, res) => {
    res.sendFile(path.resolve(__dirname, "admin-panel", "build", "index.html"));
  });
}

const server = app.listen(PORT, () => {
  console.log(`server running on port ${PORT}`);
  init();
});